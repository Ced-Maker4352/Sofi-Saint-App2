// lib/utils/web_history_fix_stub.dart

/// Non-web stub
void installWebHistoryWorkaround() {}
